NINE3DESIGNS - UNDER CONSTRUCTION PAGE
=======================================

WHAT THIS IS
A single-file "coming soon" page for client sites while you build.
Everything (logo, favicon, styling) is embedded inside index.html -
upload ONE file and nothing can break. Your branding does the advertising:
it links to nine3designs.co.uk and your Facebook / Instagram / TikTok.

HOW TO USE IT (per client)
1. Open index.html in any text editor (Notepad is fine).
2. Change the <title> at the top:
      <title>Client Name - New Website Coming Soon</title>
3. Change "Client Name" in the visible paragraph (and the meta
   description just below it if you like).
4. OPTIONAL - show the client's email: find the "contact" paragraph
   and delete the comment line above it AND the line below it,
   then swap in their email address.
5. Upload to the client's hosting as index.html.

That's it - the Nine3 credit, website link and social icons stay as they are.

NICE TO KNOW
- Colours live in the :root block at the top of the <style> section:
    --olive:#404A3B; --gold:#C8A96A; --cream:#FEF9F3;
  (Change --olive to #1c1c1c and this instantly works as a dark
  neutral version if a client's brand clashes with olive.)
- A commented-out <meta name="robots" content="noindex"> line sits in
  <head>. Uncomment it if you'd rather search engines ignore the
  placeholder page until launch.
- The page loads Raleway from Google Fonts (your brand font). If a
  client's site is offline-first it still renders fine in the system
  fallback font.
- Fully responsive, ~50KB total, no JavaScript.
